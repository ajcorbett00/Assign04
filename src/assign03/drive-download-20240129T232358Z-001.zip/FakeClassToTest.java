package assign03;

import java.util.Comparator;

public class FakeClassToTest{
    public FakeClassToTest(){
    }

}
