package assign03;

import java.util.Collection;
import java.util.Comparator;

public class SimplePriorityQueue<E> implements PriorityQueue<E> {

    private E[] queue;
    private Comparator<? super E> cmp;
    private boolean naturalOrdering;
    private int maxIndex;
    @SuppressWarnings("unchecked")
    public SimplePriorityQueue(){
        this(null);
naturalOrdering = true;

    }

    public SimplePriorityQueue(Comparator<? super E> cmp){
naturalOrdering = false;
queue = (E[])new Object[50];
this.cmp = cmp;
maxIndex = 0;
    }
@Override
    public E findMax(){
        return queue[maxIndex];
    }
@Override
    public E deleteMax(){
        queue[maxIndex] = null;
        if(maxIndex>0) {
            maxIndex--;
        }
        return queue[maxIndex];
    }
@Override
    public void insert(E item) {

}


    public void insertAll(Collection <? extends E> coll){

    }


    public boolean contains(E item){
        return false;
    }
@Override
    public int size(){
        return 0;
    }
@Override
    public boolean isEmpty(){
        return false;
    }
@Override
    public void clear(){

    }

    private int binarySearch(E target){
        return 0;
    }


}
