package assign03;

import org.junit.jupiter.api.*;

public class SimplePriorityQueueTester {
    @BeforeEach
    public void TestSetUp(){

    }

    @Test
    public void rudimentaryFeatures(){
        SimplePriorityQueue<String> basic = new SimplePriorityQueue<>();
        //SimplePriorityQueue<FakeClassToTest> basicCompare = new SimplePriorityQueue<>(new Comparator)
    }

}
